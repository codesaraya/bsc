/* THIS FILE WAS GENERATED AUTOMATICALLY BY PAYLOAD. */
/* DO NOT MODIFY IT BECAUSE IT COULD BE REWRITTEN AT ANY TIME. */
import config from '@payload-config'
import { GRAPHQL_PLAYGROUND_GET, REST_POST } from '@payloadcms/next/routes'

export const GET = GRAPHQL_PLAYGROUND_GET(config)
export const POST = REST_POST(config)
